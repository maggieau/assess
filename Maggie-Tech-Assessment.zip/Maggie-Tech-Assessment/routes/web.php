<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::group(['middleware' => 'auth'], function (){
	Route::get('/home', 'HomeController@index')->name('home');
	Route::get('/profile','ProfileController@index');
	Route::get('/employee_list', 'EmployeeListController@index');
	Route::get('/department_create','DepartmentController@insertform');
	Route::get('/department_create', 'DepartmentController@listDepartment');
	Route::post('/process_department_create','DepartmentController@insert');
	Route::get('/employee_create','EmployeeInsertController@insertform');
	Route::post('/process_employee_create','EmployeeInsertController@insert');
	Route::get('/employee_report', 'EmployeeReportController@index');
	Route::post('/process_search', 'EmployeeReportController@search');
	Route::post('/process_mgr_search', 'EmployeeReportController@searchMgr');
});



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

