<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
            $table->bigIncrements('id');			
			$table->string('employee_name');
			$table->string('email')->unique();
			$table->char('gender',1);
			$table->string('position');	
			$table->integer('department_id');	
			$table->dateTime('date_of_employment');
			$table->boolean('isManager');
			$table->integer('manager_id');
			$table->boolean('isActive')->1;
			$table->timestamp('created_at')->useCurrent();
			$table->timestamp('updated_at')->useCurrent();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
