<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    //
	
	function manager(){
		return $this->belongsTo('App\Manager');
	}
	
	function department(){
		return $this->hasOne('App\Depertment');
	}
}
