<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Manager extends Model
{
    protected $manager = "employees";
	
	function subordinate(){
		return $this->hasMany('App\Employee');
	}
}
