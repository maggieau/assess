<?php

namespace App\Providers;

use App\Department;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class DepartmentDropdownProvider extends ServiceProvider
{
    public function boot()
    {
        view()->composer('*', function($view){
			$view->with('departments', Department::all());		
		});
    }
}
