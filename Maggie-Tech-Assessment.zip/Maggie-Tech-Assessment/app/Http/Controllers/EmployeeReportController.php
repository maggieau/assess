<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Controllers\Controller;

class EmployeeReportController extends Controller
{
	public function index() {
		$employees = DB::select('select e.*, (select m.employee_name from employees as m where m.id = e.manager_id and e.manager_id <> 0) as manager_name from employees as e where e.isActive = 1');
		return view('employee_report',['employees'=>$employees]);
   }
   
    public function search(Request $request){
		$criteria = $request->input('criteria_1');
		switch ($criteria){
			case "0":
				index();				
				break;
			case "current_year":
				$currentyear = date("Y");
				$employees = DB::select('select e.*, (select m.employee_name from employees as m where m.id = e.manager_id and e.manager_id <> 0) as manager_name from employees as e where e.isActive = 1 and Year(e.date_of_employment) = ' . $currentyear);
				break;
			case "within_3mth":				
				$employees = DB::select('select e.*, (select m.employee_name from employees as m where m.id = e.manager_id and e.manager_id <> 0) as manager_name from employees as e where e.isActive = 1 and e.date_of_employment >= Date_Sub(now(), interval 3 Month)');
				break;
			case "for_5yrs":				
				$employees = DB::select('select e.*, (select m.employee_name from employees as m where m.id = e.manager_id and e.manager_id <> 0) as manager_name from employees as e where e.isActive = 1 and e.date_of_employment <= Date_Sub(now(), interval 5 Year)');
				break;
			case "10yrs_more":				
				$employees = DB::select('select e.*, (select m.employee_name from employees as m where m.id = e.manager_id and e.manager_id <> 0) as manager_name from employees as e where e.isActive = 1 and e.date_of_employment <= Date_Sub(now(), interval 10 Year)');							
				break;			
		}
		if ($employees){
			return view('employee_report',['employees'=>$employees,'hvdata'=>$criteria]);
		} else {
			return view('employee_report',['employees'=>$employees, 'nodata'=>'No data found, please search again.']);
		}	
	}
	
	public function searchMgr(Request $request){
		$criteria = $request->input('employee_mgt');
		$employees = DB::select('select e.*, (select m.employee_name from employees as m where m.id = e.manager_id and e.manager_id <> 0) as manager_name from employees as e where e.isActive = 1 and e.manager_id = ' . $criteria);
		return view('employee_report',['employees'=>$employees]);
	}
}
