<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Department;

class DepartmentController extends Controller
{
    public function insertform() {
		return view('department_create');
	}
	
	
	public function insert(Request $request) {
		$name = $request->input('department_name');		
		
		DB::insert('insert into departments (department_name) values (?)', [$name]);
		return view('process_department');
   }
}
