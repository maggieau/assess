<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class EmployeeInsertController extends Controller
{
    public function insertform() {
      return view('employee_create');
	}
	
	public function editform() {
      return view('employee_edit');
	}
   
	public function insert(Request $request) {
		$name = $request->input('employee_name');
		$email = $request->input('employee_email');
		$gender = $request->input('employee_gender');
		$date_employ = $request->input('employee_dateemploy');
		$position = $request->input('employee_position');
		$department = $request->input('department_id');
		$isManager = $request->input('employee_isManager');
		$manager_id = $request->input('employee_mgt');
		
		DB::insert('insert into employees (employee_name, email, gender, position, department_id, isManager, manager_id, date_of_employment, isActive, created_at, updated_at) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [$name, $email, $gender, $position, $department, $isManager, $manager_id, $date_employ, 1, now(), now()]);
		echo "<center><div class='font-size:45px;'>Employment System</div><div class='font-size:30px;'>Employee added successfully.</div>";
		echo '<a href = "/employee_create">Click Here</a> to go back.';
   }
}
