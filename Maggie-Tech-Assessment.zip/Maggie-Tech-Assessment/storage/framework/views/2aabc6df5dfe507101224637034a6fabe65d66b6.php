<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Add employee</title>

		<!-- bootstrap style -->
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
		
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

		<!-- Datepicker -->		
		<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">		
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>
		
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {height: 100vh;}
            .flex-center {align-items: center; display: flex;justify-content: center;}
            .position-ref {position: relative;}
            .top-right {position: absolute; right: 10px; top: 18px;}
            .content {text-align: center;}
            .title {font-size: 45px;}
			.subtitle {font-size: 30px;}
			table tr td{padding-bottom:20px; padding-right:10px}
			.btn {border-radius:14px;font-size:12px; background-color:#00baff; color:#ffffff; font-weight:bold;padding:10px;}
			.m-b-md {margin-bottom: 5px;}
			.t-s-md {margin-bottom: 30px;}
			
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
						<a href="<?php echo e(url('/profile')); ?>">Profile</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">Employment System</div>
				<div class="subtitle t-s-md">Add Employee</div>

                <form action = "/process_employee_create" method = "post">
					<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
					<table cellpadding="0" cellspacing="0" border="0">
						<tr><td><label for="employee_name">Employee Name:</label></td>
							<td><input class="form-control" type="text" name="employee_name" id="employee_name" /></td></tr>
						<tr><td><label for="employee_email">Employee email:</label></td>
							<td><input class="form-control" type="text" name="employee_email" id="employee_email" /></td></tr>
						<tr><td><label for="employee_gender">Gender:</label></td>
							<td><select class="form-control" name="employee_gender" id="employee_gender">
									<option value="0">Please choose</option>
									<option value="F">Female</option>
									<option value="M">Male</option>
								</select></td></tr>
						<tr><td><label for="employee_dateemploy">Date of employment:</label></td>
							<td><input class="date form-control" type="text" name="employee_dateemploy" id="employee_dateemploy" /></td></tr>
						<tr><td><label for="employee_position">Position:</label></td>
							<td><input class="form-control" type="text" name="employee_position" id="employee_position" /></td></tr>
						<tr><td><label for="employee_dept">Department:</label></td>
							<td><select class="form-control" name="department_id" id="department_id">
									<option value="0">Please choose</option>
									<?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>										
										<option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select></td></tr>
						<tr><td><label for="employee_isManager">Is Manager?</label></td>
							<td><select class="form-control" name="employee_isManager" id="employee_isManager">
									<option value="0">Please choose</option>
									<option value="1">Yes</option>
									<option value="0">No</option>
								</select></td></tr>
						<tr><td><label for="employee_mgt">Manager (If Any):</label></td>
							<td><select class="form-control" name="employee_mgt" id="employee_mgt">
									<option value="0">Please choose</option>
									<?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>										
										<option value="<?php echo e($manager->id); ?>"><?php echo e($manager->employee_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select></td></tr>
						<tr><td colspan="2">
								<input class="btn" type="submit" value="Add Employee" /></td></tr>
					</table>
				</form>
            </div>
        </div>
		
		<script type="text/javascript">
			$('.date').datepicker({  
				format: 'yyyy-mm-dd'
			});  
		</script>  
    </body>
</html>
<?php /**PATH C:\Users\mau\Maggie-Tech-Assessment\resources\views/employee_create.blade.php ENDPATH**/ ?>