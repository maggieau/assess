<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Create Department</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {text-align: center;}
            .title {font-size: 45px;}
			.subtitle {font-size: 30px;}
			table tr td{padding-bottom:20px; padding-right:10px}
			.btn {border-radius:14px;font-size:12px; background-color:#00baff; color:#ffffff; font-weight:bold;padding:10px;}
			
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {margin-bottom: 5px;}
			.t-s-md {margin-bottom: 30px;}
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
						<a href="<?php echo e(url('/profile')); ?>">Profile</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">Employment System</div>
				<div class="subtitle t-s-md">Create Department</div>

                <form action = "/process_department_create" method = "post">
					<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
					<table cellpadding="0" cellspacing="0" border="0">
						<tr><td>Department Name:</td>
							<td><input type="text" name="department_name" /></td></tr>
						<tr><td colspan="2">
								<input class="btn" type="submit" value="Add Department" /></td></tr>
					</table>
				</form>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\Users\mau\Maggie-Tech-Assessment\resources\views/department_create.blade.php ENDPATH**/ ?>