<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>View Employees</title>
		
		<!-- bootstrap style -->
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {height: 100vh;}
            .flex-center {align-items: center; display: flex;justify-content: center;}
            .position-ref {position: relative;}
            .top-right {position: absolute; right: 10px; top: 18px;}
            .content {text-align: center;}
            .title {font-size: 45px;}
			.subtitle {font-size: 30px;}
			.search_result_no {font-size: 20px; color:red}
			.search_result_yes {font-size: 20px; color:blue}
			table tr th{padding:10px;font-weight:bold; text-align:center; border:1px solid #cccccc}
			table tr td{padding:10px; text-align:left; border:1px solid #cccccc;}
			.btn {border-radius:14px;font-size:12px; background-color:#00baff; color:#ffffff; font-weight:bold;padding:10px;}
			.m-b-md {margin-bottom: 5px;}
			.t-s-md {margin-bottom: 30px;}
			
            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            
        </style>
		
		<script type="text/javascript">
			$(document).ready(function() {
				$('#criteria_1').on('change', function() {
					this.form.submit();
				});
				$('#employee_mgt').on('change', function() {
					this.form.submit();
				});
			});
        </script>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            @if (Route::has('login'))
                <div class="top-right links">
                    @auth
                        <a href="{{ url('/home') }}">Home</a>
						<a href="{{ url('/profile') }}">Profile</a>
                    @else
                        <a href="{{ route('login') }}">Login</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}">Register</a>
                        @endif
                    @endauth
                </div>
            @endif

            <div class="content">
                <div class="title m-b-md">Employment System</div>
				<div class="subtitle t-s-md">List of Employees</div>
				
				<center><a href="/employee_report">Reset</a></center><br />
				
				<form action = "/process_search" method = "post">
					<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
					<table cellspacing="0" cellpadding="0" style="border:1px solid #cccccc; color:#636b6f;width:800px">
						<thead>
							<tr><th colspan="2">Search Criteria</th></tr>						
						</thead>
						<tbody>							
							<tr><td width="50%"><label for="criteria_1">Joined Company for:</label></td>
								<td width="50%"><select class="form-control" name="criteria_1" id="criteria_1">
										<option value="0">Please choose</option>
										<option value="current_year">Joined in current year</option>
										<option value="within_3mth">Within three months</option>
										<option value="for_5yrs">More than 5 years</option>
										<option value="10yrs_more">10 years or more</option>
									</select></td></tr>							
						</tbody>
					</table>
				</form>
				<form action = "/process_mgr_search" method = "post">
					<input type = "hidden" name = "_token" value = "<?php echo csrf_token(); ?>">
					<table cellspacing="0" cellpadding="0" style="border:1px solid #cccccc; color:#636b6f;width:800px">
						<tr><td colspan="2" style="text-align:center">Or</td></tr>
							<tr><td width="50%"><label for="criteria_1">Show this manager's subordinate:</label></td>
								<td width="50%"><select class="form-control" name="employee_mgt" id="employee_mgt">
										<option value="0">Please choose</option>
										@foreach($managers as $manager)										
											<option value="{{$manager->id}}">{{$manager->employee_name}}</option>
										@endforeach
									</select></td></tr>
					</table>
				</form>
				<br/><br />	
								
				<div class="search_result_no t-s-md">{{ isset($nodata) ? $nodata : '' }}</div>				
				<div class="search_result_yes t-s-md">				
						@if (isset($hvdata))
							@if ($hvdata =='within_3mth')
								Within three months
							@elseif ($hvdata =='current_year')
								Joined in current year
							@elseif ($hvdata =='for_5yrs')
								More than 5 years
							@elseif ($hvdata =='10yrs_more')
								10 years or more
							@endif
						@else
							
						@endif
				</div>
			
								
                <table cellspacing="0" cellpadding="0" style="border:1px solid #cccccc; color:#636b6f;width:800px">
					<thead>
						<tr><th>Email</th><th>Name</th><th>Position</th><th>Date of Employment</th><th>Manager</th></tr>
					</thead>
					<tbody>
						@foreach ($employees as $employee)
						<tr><td>{{ $employee->email }}</td>
							<td>{{ $employee->employee_name }}</td>
							<td>{{ $employee->position }}</td>
							<td>{{ $employee->date_of_employment }}</td>
							<td>{{ $employee->manager_name }}</td>
						</tr>
						@endforeach
					</tbody>
				</table>
            </div>
        </div>
    </body>
</html>
