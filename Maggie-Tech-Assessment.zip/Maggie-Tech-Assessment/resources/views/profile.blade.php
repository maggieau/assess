@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                 <div class="card-header">Welcome, {{Auth::user()->name}}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    View or edit your profile here:
					<br /><br />
					<form action="" method="post">
						<label for="name">Employee Name: {{Auth::user()->name}}</label>
						<br />
						<label for="email">Email: {{Auth::user()->email}}</label>
						<br />
						
						<button type="submit" class="btn btn-primary">Save</button>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
